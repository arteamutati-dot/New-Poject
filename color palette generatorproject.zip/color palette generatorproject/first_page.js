const paletteContainer = document.getElementById('paletteContainer');
const generateBtn = document.getElementById('generateBtn');
const saveBtn = document.getElementById('saveBtn');
const clearBtn = document.getElementById('clearBtn');
const colorCountSelect = document.getElementById('colorCount');
const themeToggle = document.getElementById('themeToggle');
const viewSavedBtn = document.getElementById('viewSavedBtn');

const modal = document.getElementById('savedModal');
const closeModal = document.getElementById('closeModal');
const savedList = document.getElementById('savedList');

const PALETTE_KEY = 'savedColorPalettes_v2';
let NUM_COLS = parseInt(colorCountSelect.value);
let isDark = true;

function randomColor() {
  const hex = Math.floor(Math.random() * 0xFFFFFF).toString(16).padStart(6, '0');
  return '#' + hex.toUpperCase();
}

function contrastColor(hex) {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b);
  return luminance > 150 ? '#0b1220' : '#FFFFFF';
}

function showToast(text) {
  let t = document.querySelector('.copied-toast');
  if (!t) {
    t = document.createElement('div');
    t.className = 'copied-toast';
    document.body.appendChild(t);
  }
  t.textContent = text;
  t.classList.add('show');
  clearTimeout(t.hideTimeout);
  t.hideTimeout = setTimeout(() => t.classList.remove('show'), 1400);
}

function buildColumns() {
  paletteContainer.innerHTML = '';
  for (let i = 0; i < NUM_COLS; i++) {
    const col = document.createElement('div');
    col.className = 'color-col';
    col.dataset.index = i;

    const info = document.createElement('div');
    info.className = 'col-info';

    const hex = document.createElement('div');
    hex.className = 'hex';
    hex.title = 'Click to copy';

    const actions = document.createElement('div');
    actions.className = 'actions';

    const lockBtn = document.createElement('button');
    lockBtn.className = 'lock-btn';
    lockBtn.innerHTML = '🔓 Lock';
    lockBtn.title = 'Lock color';

    hex.addEventListener('click', async (e) => {
      const color = e.currentTarget.textContent.trim();
      try {
        await navigator.clipboard.writeText(color);
        showToast(`${color} copied`);
      } catch {
        showToast('Copied!');
      }
    });

    lockBtn.addEventListener('click', () => {
      lockBtn.classList.toggle('locked');
      lockBtn.innerHTML = lockBtn.classList.contains('locked') ? '🔒 Locked' : '🔓 Lock';
    });

    actions.appendChild(lockBtn);
    info.appendChild(hex);
    info.appendChild(actions);
    col.appendChild(info);
    paletteContainer.appendChild(col);
  }
}

function applyPalette(existingColors = null) {
  const cols = Array.from(document.querySelectorAll('.color-col'));
  cols.forEach((col, idx) => {
    const locked = col.querySelector('.lock-btn')?.classList.contains('locked');
    if (locked) return;

    const color = (existingColors && existingColors[idx]) ? existingColors[idx] : randomColor();
    col.style.background = color;
    const hexDiv = col.querySelector('.hex');
    hexDiv.textContent = color;
    const textColor = contrastColor(color);
    hexDiv.style.color = textColor;
    const lockBtn = col.querySelector('.lock-btn');
    if (lockBtn) lockBtn.style.color = textColor;
  });
}

function loadSavedPalettes() {
  try {
    const raw = localStorage.getItem(PALETTE_KEY);
    if (!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function saveCurrentPalette() {
  const cols = Array.from(document.querySelectorAll('.color-col'));
  const colors = cols.map(c => c.querySelector('.hex').textContent.trim());
  let saved = loadSavedPalettes();
  saved.push(colors);
  localStorage.setItem(PALETTE_KEY, JSON.stringify(saved));
  showToast('Palette saved');
}

function clearSavedPalettes() {
  localStorage.removeItem(PALETTE_KEY);
  showToast('Saved palettes cleared');
}

function openSavedModal() {
  savedList.innerHTML = '';
  const saved = loadSavedPalettes();
  if (!saved.length) {
    savedList.innerHTML = '<p>No saved palettes yet.</p>';
  } else {
    saved.forEach((palette, i) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'saved-item';
      palette.forEach(color => {
        const swatch = document.createElement('div');
        swatch.className = 'swatch';
        swatch.style.background = color;
        swatch.title = color;
        wrapper.appendChild(swatch);
      });
      wrapper.addEventListener('click', () => {
        NUM_COLS = palette.length;
        colorCountSelect.value = NUM_COLS;
        buildColumns();
        applyPalette(palette);
        closeModal.click();
      });
      savedList.appendChild(wrapper);
    });
  }
  modal.style.display = 'block';
}

function toggleTheme() {
  isDark = !isDark;
  document.body.classList.toggle('light-theme', !isDark);
  themeToggle.textContent = isDark ? '🌙 Dark' : '☀️ Light';
}

function init() {
  buildColumns();
  applyPalette();

  generateBtn.addEventListener('click', () => applyPalette());
  saveBtn.addEventListener('click', saveCurrentPalette);
  clearBtn.addEventListener('click', clearSavedPalettes);
  colorCountSelect.addEventListener('change', e => {
    NUM_COLS = parseInt(e.target.value);
    buildColumns();
    applyPalette();
  });
  themeToggle.addEventListener('click', toggleTheme);
  viewSavedBtn.addEventListener('click', openSavedModal);

  closeModal.addEventListener('click', () => modal.style.display = 'none');
  window.addEventListener('click', (e) => {
    if (e.target === modal) modal.style.display = 'none';
  });

  window.addEventListener('keydown', (e) => {
    if (e.code === 'Space' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'BUTTON') {
      e.preventDefault();
      applyPalette();
    }
  });
}

init();
